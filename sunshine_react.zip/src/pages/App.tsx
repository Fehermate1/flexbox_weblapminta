import '../styles/style.css';
import kep from '../yandhi.png';

const Swag = () => {
    return (
        <div className="fortnite">
            <div className="flex-container1">
                <div className="element1"></div>
                <div className="element1"></div>
                <div className="element1"></div>
                <div className="element1"></div>
            </div>
            <div className="main2">
                <div className="flex-container2">
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                </div>
                <div className="flex-container3">
                    <img src={kep} alt="Swag" />
                </div>
            </div>
        </div>
    );
};

export default Swag;
