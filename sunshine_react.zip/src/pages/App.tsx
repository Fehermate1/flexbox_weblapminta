import '../styles/style.css';

const Swag = () => {
    return (
        <div>
            <div className="main">
                <div className="flex-container1">
                    <div className="element1"></div>
                    <div className="element1"></div>
                    <div className="element1"></div>
                    <div className="element1"></div>
                </div>
                <div className="flex-container2">
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                    <div className="element2"></div>
                </div>
            </div>
            <div className="main2">
                <div className="flex-container3">
                    <div className="element3"></div>
                </div>
            </div>
        </div>
    );
};

export default Swag;
